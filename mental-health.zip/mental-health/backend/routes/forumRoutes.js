const express = require('express');
const router = express.Router();
const ForumPost = require('../models/ForumPost');
router.post('/', async (req, res) => {
  const post = new ForumPost({ content: req.body.content });
  await post.save();
  res.json(post);
});
router.get('/', async (req, res) => {
  const posts = await ForumPost.find().sort({ createdAt: -1 });
  res.json(posts);
});
module.exports = router;