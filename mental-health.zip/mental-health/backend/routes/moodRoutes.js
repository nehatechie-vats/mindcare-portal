const express = require('express');
const router = express.Router();
const Mood = require('../models/Mood');
router.post('/', async (req, res) => {
  const newMood = new Mood({ mood: req.body.mood });
  await newMood.save();
  res.json(newMood);
});
router.get('/', async (req, res) => {
  const moods = await Mood.find().sort({ date: -1 });
  res.json(moods);
});
module.exports = router;