const express = require('express');
const router = express.Router();
const Session = require('../models/Session');
router.post('/', async (req, res) => {
  const newSession = new Session(req.body);
  await newSession.save();
  res.json(newSession);
});
router.get('/', async (req, res) => {
  const sessions = await Session.find();
  res.json(sessions);
});
module.exports = router;