const express = require('express');
const router = express.Router();
const Journal = require('../models/Journal');
router.post('/', async (req, res) => {
  const newEntry = new Journal({ content: req.body.content });
  await newEntry.save();
  res.json(newEntry);
});
router.get('/', async (req, res) => {
  const entries = await Journal.find().sort({ createdAt: -1 });
  res.json(entries);
});
module.exports = router;
