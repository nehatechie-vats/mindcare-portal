const mongoose = require('mongoose');
const sessionSchema = new mongoose.Schema({
  name: String,
  date: String,
  time: String,
});
module.exports = mongoose.model('Session', sessionSchema);