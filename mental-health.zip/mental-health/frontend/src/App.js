import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Journal from './pages/Journal';
import Mood from './pages/Mood';
import Sessions from './pages/Session';
import Forum from './pages/Forum';
import SOSButton from './components/SosButton';
import ChatBot from './components/ChatBot';
import Login from './pages/Login'; // Add Login page
import Register from './pages/Register'; // Add Register page
import './App.css'; // Assuming you have some CSS for styling
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <Router>
      <div>
        <SOSButton />
        <ChatBot />
        <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />

          <Route path="/journal" element={<Journal />} />
          <Route path="/mood" element={<Mood />} />
          <Route path="/sessions" element={<Sessions />} />
          <Route path="/forum" element={<Forum />} />
          <Route path="/register" element={<Register />} /> {/* Add Register page */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
