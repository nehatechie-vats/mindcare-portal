import React from 'react';
import './Chatbot.css'; // Assuming you have some CSS for styling
export default function ChatBot() {
  return <div style={{ position: 'fixed', bottom: 10, right: 10 }}>Need help? Start chatting!</div>;
}