import React from 'react';


// In your src/components/SosButton.js
import './SosButton.css';

export default function SOSButton() {
  const handleClick = () => {
    alert('SOS Alert! Help is on the way.');
  };
  return <button onClick={handleClick} style={{ position: 'fixed', top: 10, right: 10 }}>SOS</button>;
}
