import React, { useState, useEffect } from 'react';
import axios from 'axios';
export default function Journal() {
  const [content, setContent] = useState('');
  const [entries, setEntries] = useState([]);
  const submitEntry = async () => {
    await axios.post('http://localhost:5000/api/journals', { content });
    setContent('');
    fetchEntries();
  };
  const fetchEntries = async () => {
    const res = await axios.get('http://localhost:5000/api/journals');
    setEntries(res.data);
  };
  useEffect(() => { fetchEntries(); }, []);
  return (
    <div>
      <h2>Journal</h2>
      <textarea value={content} onChange={e => setContent(e.target.value)} />
      <button onClick={submitEntry}>Submit</button>
      <ul>
        {entries.map((e, i) => <li key={i}>{e.content}</li>)}
      </ul>
    </div>
  );
}