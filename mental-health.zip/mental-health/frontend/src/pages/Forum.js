import React, { useState, useEffect } from 'react';
import axios from 'axios';
export default function Forum() {
  const [content, setContent] = useState('');
  const [posts, setPosts] = useState([]);
  const submitPost = async () => {
    await axios.post('http://localhost:5000/api/forums', { content });
    setContent('');
    fetchPosts();
  };
  const fetchPosts = async () => {
    const res = await axios.get('http://localhost:5000/api/forums');
    setPosts(res.data);
  };
  useEffect(() => { fetchPosts(); }, []);
  return (
    <div>
      <h2>Community Forum</h2>
      <textarea value={content} onChange={e => setContent(e.target.value)} />
      <button onClick={submitPost}>Post</button>
      <ul>
        {posts.map((p, i) => <li key={i}>{p.content}</li>)}
      </ul>
    </div>
  );
}