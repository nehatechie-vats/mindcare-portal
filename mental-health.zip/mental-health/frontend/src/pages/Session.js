import React, { useState, useEffect } from 'react';
import axios from 'axios';
export default function Session() {
  const [session, setSession] = useState({ name: '', date: '', time: '' });
  const [sessions, setSessions] = useState([]);
  const bookSession = async () => {
    await axios.post('http://localhost:5000/api/sessions', session);
    setSession({ name: '', date: '', time: '' });
    fetchSessions();
  };
  const fetchSessions = async () => {
    const res = await axios.get('http://localhost:5000/api/sessions');
    setSessions(res.data);
  };
  useEffect(() => { fetchSessions(); }, []);
  return (
    <div>
      <h2>Book Counseling Session</h2>
      <input placeholder="Name" value={session.name} onChange={e => setSession({ ...session, name: e.target.value })} />
      <input placeholder="Date" type="date" value={session.date} onChange={e => setSession({ ...session, date: e.target.value })} />
      <input placeholder="Time" type="time" value={session.time} onChange={e => setSession({ ...session, time: e.target.value })} />
      <button onClick={bookSession}>Book</button>
      <ul>
        {sessions.map((s, i) => <li key={i}>{s.name} - {s.date} at {s.time}</li>)}
      </ul>
    </div>
  );
}
