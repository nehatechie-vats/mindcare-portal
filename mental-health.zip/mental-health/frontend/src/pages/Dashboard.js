import React from "react";
import { Link } from "react-router-dom";
import SOSButton from "../components/SosButton";
import ChatBot from "../components/ChatBot";
import "./Dashboard.css"; // Optional styling

const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <h2>Welcome to MindCare Portal 💚</h2>
      <p>Your safe space for journaling, mood tracking & support</p>

      <div className="feature-links">
        <Link to="/journal">📝 Journal</Link>
        <Link to="/mood">📊 Mood Tracker</Link>
        <Link to="/sessions">📅 Counseling Sessions</Link>
        <Link to="/forum">🗣️ Community Forum</Link>
      </div>

      <SOSButton />
      <ChatBot />
    </div>
  );
};

export default Dashboard;
