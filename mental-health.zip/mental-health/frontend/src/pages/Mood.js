import React, { useState, useEffect } from 'react';
import axios from 'axios';
export default function Mood() {
  const [mood, setMood] = useState('');
  const [moods, setMoods] = useState([]);
  const submitMood = async () => {
    await axios.post('http://localhost:5000/api/moods', { mood });
    setMood('');
    fetchMoods();
  };
  const fetchMoods = async () => {
    const res = await axios.get('http://localhost:5000/api/moods');
    setMoods(res.data);
  };
  useEffect(() => { fetchMoods(); }, []);
  return (
    <div>
      <h2>Mood Tracker</h2>
      <input value={mood} onChange={e => setMood(e.target.value)} />
      <button onClick={submitMood}>Track</button>
      <ul>
        {moods.map((m, i) => <li key={i}>{m.mood}</li>)}
      </ul>
    </div>
  );
}